# FLYBUY
Team FLYBUY
FLYBUY E-commerce Website with all the features.
Pre requisites
•	JDK8
•	Java Hibernate
•	Oracle DB 
•	Tomcat v7
Installation
•	Open Brower and connect to internet and hit the below link-
•	https://github.com/grewalmanoj221/FLYBUY.git and download the project.

•	Project zip will be downloaded into your system.

•	Once the zip has been download to your local machine then unzip it and then open the directory. It will have two directory naming Project and Project_Picture and third will be file named export.sql which have the database backup.

•	 Open your Eclipse IDE for java and import the Project directory into your workbench and open it. Change the preference to java EE and choose Apache Tomcat Server 7.

•	Open Oracle SQL Plus cmd prompt and Copy all the data from export.sql file from Drive directory and paste it in SQL plus prompt.

•	Open hibernate.cfg.xml from src and change username and password to your details of Oracle DB in which user you paste your SQL file data.

•	Copy the product_picture directory content and paste it to the link  “D:\JAVA\Eclipse\.metadata\.plugins\org.eclipse.wst.server.core\tmp3\wtpwebapps\Project\img\products”, here “D:\JAVA\Eclipse” is my eclipse workspace directory and choose your workspace link and paste the content there.

•	Now run the project and select run on server and enjoy with your E commerce website.

•	For Admin rights below are the details for logging into admin account:
	Email 	: grewalmanoj221@gmail.com
	Password	: Badhra
	
	Normal user-
	Email 	: himnish@gmail.com
	Password	: Rohini
	



